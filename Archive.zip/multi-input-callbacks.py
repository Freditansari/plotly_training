import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

import plotly.graph_objs as go
import numpy as np
import pandas as pd

df = pd.read_csv('gapminderDataFiveYear.csv')
colors = {'background': '#111111', 'text': '#7FDBFF'}
app = dash.Dash()

year_options =[]
for year in df['year'].unique():
    year_options.append({'label': str(year), 'value': year})

app.layout = html.Div([
    dcc.Graph(id='graph'),
    dcc.Dropdown(id='year-picker', options =year_options, value=df['year'].min())

])


@app.callback(Output(component_id='graph', component_property='figure'),
              [Input(component_id='year-picker', component_property='value')])
def update_figure(selected_year):
    return


if __name__ == '__main__':
    app.run_server()
